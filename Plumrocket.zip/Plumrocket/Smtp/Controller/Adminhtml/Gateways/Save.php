<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Smtp\Controller\Adminhtml\Gateways;

use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\View\Result\PageFactory;
use Plumrocket\Smtp\Model\Gateway;

/**
 * @since 1.1.0
 */
class Save extends Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var Gateway
     */
    protected $gateways;

    /**
     * @var EncryptorInterface
     */
    protected $encrypt;

    /**
     * Save constructor.
     *
     * @param Context            $context
     * @param EncryptorInterface $encrypt
     * @param PageFactory        $resultPageFactory
     * @param Gateway            $gateways
     */
    public function __construct(
        Context $context,
        EncryptorInterface $encrypt,
        PageFactory $resultPageFactory,
        Gateway $gateways
    ) {
        $this->encrypt = $encrypt;
        $this->gateways = $gateways;
        $this->resultPageFactory = $resultPageFactory;

        parent::__construct($context);
    }

    /**
     * @inheritdoc
     */
    public function execute()
    {
        $data = $this->getRequest()->getParams();
        $resultRedirect = $this->resultRedirectFactory->create();
        $gatewayId = 0;

        try {
            if (! empty($data)) {
                if (isset($data['entity_id'])) {
                    $this->gateways->load($data['entity_id']);
                }

                $data['password'] = $this->encrypt->encrypt($data['password']);
                $this->gateways->setData($data)->save();
                $gatewayId = $this->gateways->getId();
            }

            $this->messageManager->addSuccessMessage(__('Email gateway successfully saved'));
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the email gateway.'));
        }

        if (isset($data['back'])) {
            $resultRedirect->setPath('*/*/edit', ['id' => $gatewayId, '_current' => true]);
        } else {
            $resultRedirect->setPath('prsmtp/gateways/index');
        }

        return $resultRedirect;
    }
}
