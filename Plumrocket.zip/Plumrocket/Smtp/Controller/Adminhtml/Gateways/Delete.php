<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Smtp\Controller\Adminhtml\Gateways;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Framework\App\RequestInterface;
use Plumrocket\Smtp\Model\GatewayFactory;
use Plumrocket\Smtp\Model\ResourceModel\GatewaysFactory;

/**
 * @since 1.1.0
 */
class Delete extends Action
{
    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var \Plumrocket\Smtp\Model\ResourceModel\Gateway
     */

    private $gatewaysResource;

    /**
     * @var \Plumrocket\Smtp\Model\Gateway
     */
    private $gatewayFactory;

    /**
     * @param \Magento\Backend\App\Action\Context          $context
     * @param \Plumrocket\Smtp\Model\ResourceModel\Gateway $gatewaysResource
     * @param \Plumrocket\Smtp\Model\GatewayFactory        $gatewaysFactory
     */
    public function __construct(
        Context $context,
        \Plumrocket\Smtp\Model\ResourceModel\Gateway $gatewaysResource,
        GatewayFactory $gatewaysFactory
    ) {
        $this->request = $context->getRequest();
        $this->gatewaysResource = $gatewaysResource;
        $this->gatewayFactory = $gatewaysFactory;
        parent::__construct($context);
    }

    /**
     * @inheritdoc
     */
    public function execute()
    {
        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $gatewayId = $this->getRequest()->getParam('gateway_id');
        try {
            if ($gatewayId) {
                /** @var \Plumrocket\Smtp\Api\Data\GatewayInterface|\Plumrocket\Smtp\Model\Gateway $gateway */
                $gateway = $this->gatewayFactory->create();
                $this->gatewaysResource->load($gateway, $gatewayId);
                if ($gateway->getId()) {
                    $this->gatewaysResource->delete($gateway);
                    $this->messageManager->addSuccessMessage(__('You deleted the gateway.'));

                    return $resultRedirect->setPath('*/*/');
                }
            }
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());

            return $resultRedirect->setPath('*/*/edit', ['rule_id' => $gatewayId]);
        }
        $this->messageManager->addErrorMessage(__('We can\'t find a gateway to delete.'));

        return $resultRedirect->setPath('*/*/');
    }
}
