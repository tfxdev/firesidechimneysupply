<?php
/**
 * Plumrocket Inc.
 * NOTICE OF LICENSE
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Smtp\Controller\Adminhtml\Gateways;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Plumrocket\Smtp\Model\ResourceModel\Gateway;
use Plumrocket\Smtp\Model\ResourceModel\Gateway\CollectionFactory;

/**
 * @since 1.1.0
 */
class MassDelete extends Action
{
    /**
     * @var Filter
     */
    private $filter;

    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    /**
     * @var \Plumrocket\Smtp\Model\ResourceModel\Gateway
     */
    private $gatewayResource;

    /**
     * @param \Magento\Backend\App\Action\Context                            $context
     * @param \Magento\Ui\Component\MassAction\Filter                        $filter
     * @param \Plumrocket\Smtp\Model\ResourceModel\Gateway\CollectionFactory $collectionFactory
     * @param \Plumrocket\Smtp\Model\ResourceModel\Gateway                   $gatewayResource
     */
    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory,
        Gateway $gatewayResource
    ) {
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->gatewayResource = $gatewayResource;
        parent::__construct($context);
    }

    /**
     * Execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     * @throws \Magento\Framework\Exception\LocalizedException|\Exception
     */
    public function execute()
    {
        /** @var \Plumrocket\Smtp\Model\ResourceModel\Gateway\Collection $collection */
        $collection = $this->filter->getCollection($this->collectionFactory->create());
        $collectionSize = $collection->getSize();

        foreach ($collection->getItems() as $gateway) {
            $this->gatewayResource->delete($gateway);
        }

        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been deleted.', $collectionSize));

        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('*/*/');
    }
}
