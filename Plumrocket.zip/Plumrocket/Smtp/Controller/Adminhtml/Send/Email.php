<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Smtp\Controller\Adminhtml\Send;

use Magento\Framework\Controller\ResultFactory;

class Email extends \Magento\Backend\App\Action
{
    /**
     * @var \Plumrocket\Smtp\Helper\Send\
     */
    private $emailHelper;

    /**
     * @var \Plumrocket\Smtp\Helper\Data
     */
    private $dataHelper;

    /**
     * @var array
     */
    private $errorMessage = [];

    /**
     * @var \Magento\Framework\Validator\EmailAddress
     */
    private $emailAddress;

    /**
     * @param \Plumrocket\Smtp\Helper\Send\Email        $emailHelper
     * @param \Plumrocket\Smtp\Helper\Data              $dataHelper
     * @param \Magento\Backend\App\Action\Context       $context
     * @param \Magento\Framework\Validator\EmailAddress $emailAddress
     */
    public function __construct(
        \Plumrocket\Smtp\Helper\Send\Email $emailHelper,
        \Plumrocket\Smtp\Helper\Data $dataHelper,
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Validator\EmailAddress $emailAddress
    ) {
        $this->emailHelper = $emailHelper;
        $this->dataHelper = $dataHelper;

        parent::__construct($context);
        $this->emailAddress = $emailAddress;
    }

    /**
     * @inheritdoc
     */
    public function execute()
    {
        $postData = $this->getRequest()->getParams();

        try {
            if ($this->validateData($postData)) {
                $data['message'] = __('Email was sent successfully.');
                $this->dataHelper->setConnectionData($postData);
                $this->emailHelper->sendTestEmail($postData['template'], $postData['from'], $postData['to']);
            } else {
                $data['message'] = __('Error(s)') . ': ' . implode(' ', $this->errorMessage);
            }
        } catch (\Exception $e) {
            $data['message'] = $e->getMessage();
        }

        return $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData($data);
    }

    /**
     * Validate credentials.
     *
     * @param array $postData
     * @return bool
     */
    private function validateData(array $postData): bool
    {
        $isValid = true;

        if (! $this->emailAddress->isValid(trim((string) $postData['to']))) {
            $isValid = false;
            $this->errorMessage[] = __('Email address is invalid.');
        }

        if (! trim((string) $postData['host'])) {
            $isValid = false;
            $this->errorMessage[] = __('SMTP host is invalid.');
        }

        if (! trim((string) $postData['port'])) {
            $isValid = false;
            $this->errorMessage[] = __('SMTP port is invalid.');
        }

        return $isValid;
    }
}
