<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Smtp\Cron;

use Exception;

class AutoClear
{
    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;

    /**
     * @var \Plumrocket\Smtp\Model\ResourceModel\Log
     */
    protected $log;

    /**
     * @var \Plumrocket\Smtp\Helper\Data
     */
    private $dataHelper;

    /**
     * @param \Psr\Log\LoggerInterface                 $logger
     * @param \Plumrocket\Smtp\Helper\Data             $dataHelper
     * @param \Plumrocket\Smtp\Model\ResourceModel\Log $log
     */
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        \Plumrocket\Smtp\Helper\Data $dataHelper,
        \Plumrocket\Smtp\Model\ResourceModel\Log $log
    ) {
        $this->logger = $logger;
        $this->log = $log;
        $this->dataHelper = $dataHelper;
    }

    /**
     * Clear old logs.
     *
     * @return void
     */
    public function execute(): void
    {
        if (! $this->dataHelper->canRunAutoClear()) {
            return;
        }

        try {
            $this->log->clearLogsUntilDate($this->dataHelper->getRemoveTime());
        } catch (Exception $exception) {
            $this->logger->critical($exception);
        }
    }
}
