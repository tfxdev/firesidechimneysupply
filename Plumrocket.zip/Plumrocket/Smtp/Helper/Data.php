<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Smtp\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Stdlib\DateTime\DateTime;

class Data extends AbstractHelper
{

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    private $dateTime;

    /**
     * @var Config
     */
    private $configHelper;

    /**
     * @var array
     */
    private $options;

    /**
     * @var array
     */
    private $connectionData;

    /**
     * @var bool
     */
    private $forTest = false;

    /**
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     * @param \Plumrocket\Smtp\Helper\Config              $configHelper
     * @param \Magento\Framework\App\Helper\Context       $context
     */
    public function __construct(
        DateTime $dateTime,
        Config $configHelper,
        Context $context
    ) {
        parent::__construct($context);
        $this->configHelper = $configHelper;
        $this->dateTime = $dateTime;
    }

    /**
     * Check if can auto clean.
     *
     * @return bool
     */
    public function canRunAutoClear(): bool
    {
        return $this->configHelper->isModuleEnabled()
            && $this->configHelper->getLogEnabled()
            && ! empty($this->configHelper->getClearEmailLogDays());
    }

    /**
     * @return false|int
     */
    public function getRemoveTime()
    {
        return strtotime($this->dateTime->gmtDate())
            - strtotime('+' . $this->configHelper->getClearEmailLogDays() . ' days');
    }

    /**
     * @param null $store
     * @return array
     */
    public function getOptionsForNewVersion($store = null)
    {
        if (! empty($this->options)) {
            return $this->options;
        }

        $options = [];
        $connectionData = $this->getConnectionData($store);

        if ($auth = $connectionData['auth']) {
            $options['connection_class'] = $auth;
            $options['connection_config'] = [
                'username' => $connectionData['username'],
                'password' => $connectionData['password']
            ];
        }

        if ($protocol = $connectionData['ssl']) {
            $options['connection_config']['ssl'] = $protocol;
        }

        $options['host'] = $connectionData['host'];
        $options['port'] = $connectionData['port'];

        return $this->options = $options;
    }

    /**
     * @param $data
     */
    public function setConnectionData($data)
    {
        $password = $data['password'];

        if (empty(str_replace('*', '', $password))) {
            $password = $this->configHelper->getPassword();
        }

        $this->connectionData = [
            'auth' => $data['authentication'],
            'username' => $data['username'],
            'password' => $password,
            'ssl' => $data['encryption'],
            'host' => $data['host'],
            'port' => $data['port']
        ];

        $this->forTest = true;
    }

    /**
     * @param null $store
     * @return array
     */
    public function getConnectionData($store = null)
    {
        if ($this->forTest) {
            return $this->connectionData;
        }

        return [
            'auth' => $this->configHelper->getAuthentication($store),
            'username' => $this->configHelper->getUsername($store),
            'password' => $this->configHelper->getPassword($store),
            'ssl' => $this->configHelper->getEncryption($store),
            'host' => $this->configHelper->getHost($store),
            'port' => $this->configHelper->getPort($store)
        ];
    }

    /**
     * @param $store
     * @return bool
     */
    public function hostExist($store)
    {
        return isset($this->connectionData['host']) || $this->configHelper->getHost($store);
    }
}
