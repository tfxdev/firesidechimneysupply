<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Smtp\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Encryption\EncryptorInterface;
use Plumrocket\Base\Api\ConfigUtilsInterface;

class Config extends AbstractHelper
{
    /**
     * @var string
     */
    private const CONFIGURATION_SECTION = 'configuration';

    /**
     * @var string
     */
    private const TEST_EMAIL_SECTION = 'test_email';

    /**
     * @var string
     */
    private const DEVELOPER_SECTION = 'developer';

    /**
     * @var \Magento\Framework\Encryption\EncryptorInterface
     */
    private $encryptor;

    /**
     * @var \Plumrocket\Base\Api\ConfigUtilsInterface
     */
    private $configUtils;

    /**
     * Config constructor.
     *
     * @param \Magento\Framework\App\Helper\Context            $context
     * @param \Magento\Framework\Encryption\EncryptorInterface $encryptor
     * @param \Plumrocket\Base\Api\ConfigUtilsInterface        $configUtils
     */
    public function __construct(
        Context $context,
        EncryptorInterface $encryptor,
        ConfigUtilsInterface $configUtils
    ) {
        parent::__construct($context);
        $this->encryptor = $encryptor;
        $this->configUtils = $configUtils;
    }

    /**
     * Check if module is enabled.
     *
     * @param null $store
     * @param null $scope
     * @return bool
     */
    public function isModuleEnabled($store = null, $scope = null): bool
    {
        return $this->configUtils->isSetFlag('prsmtp/general/enabled', $store, $scope);
    }

    /**
     * Retrieve config value according to current section identifier
     *
     * @param string $path
     * @param null   $store
     * @param        $scope
     * @return mixed
     */
    private function getConfigForCurrentSection($path, $store = null, $scope = ScopeConfigInterface::SCOPE_TYPE_DEFAULT)
    {
        return $this->scopeConfig->getValue(
            'prsmtp/' . $path,
            $scope,
            $store
        );
    }

    /**
     * @param null|string|int $store
     * @return mixed
     */
    public function getHost($store = null)
    {
        return $this->getConfigForCurrentSection(
            self::CONFIGURATION_SECTION . '/host',
            $store
        );
    }

    /**
     * @param null|string|int $store
     * @return mixed
     */
    public function getPort($store = null)
    {
        return $this->getConfigForCurrentSection(
            self::CONFIGURATION_SECTION . '/port',
            $store
        );
    }

    /**
     * @param null|string|int $store
     * @return mixed
     */
    public function getEncryption($store = null)
    {
        return $this->getConfigForCurrentSection(
            self::CONFIGURATION_SECTION . '/encryption',
            $store
        );
    }

    /**
     * @param null|string|int $store
     * @return mixed
     */
    public function getAuthentication($store = null)
    {
        return $this->getConfigForCurrentSection(
            self::CONFIGURATION_SECTION . '/authentication',
            $store
        );
    }

    /**
     * @param null|string|int $store
     * @return mixed
     */
    public function getUsername($store = null)
    {
        return $this->getConfigForCurrentSection(
            self::CONFIGURATION_SECTION . '/username',
            $store
        );
    }

    /**
     * @param null|string|int $store
     * @return string
     */
    public function getPassword($store = null)
    {
        $encryptValue = $this->getConfigForCurrentSection(
            self::CONFIGURATION_SECTION . '/password',
            $store
        );

        return $this->encryptor->decrypt($encryptValue);
    }

    // Test Email Section

    /**
     * @param null|string|int $store
     * @return mixed
     */
    public function getTemplate($store = null)
    {
        return $this->getConfigForCurrentSection(
            self::TEST_EMAIL_SECTION . '/template',
            $store
        );
    }

    /**
     * @param null|string|int $store
     * @return mixed
     */
    public function getFrom($store = null)
    {
        return $this->getConfigForCurrentSection(
            self::TEST_EMAIL_SECTION . '/from',
            $store
        );
    }

    /**
     * @param null|string|int $store
     * @return mixed
     */
    public function getTo($store = null)
    {
        return $this->getConfigForCurrentSection(
            self::TEST_EMAIL_SECTION . '/to',
            $store
        );
    }

    // Developer Section

    /**
     * @param null|string|int $store
     * @return bool
     */
    public function getEmailSendingEnabled($store = null)
    {
        return (bool) $this->getConfigForCurrentSection(
            self::DEVELOPER_SECTION . '/email_sending',
            $store
        );
    }

    /**
     * @param null|string|int $store
     * @return bool
     */
    public function getLogEnabled($store = null)
    {
        return (bool) $this->getConfigForCurrentSection(
            self::DEVELOPER_SECTION . '/log',
            $store
        );
    }

    /**
     * @param null|string|int $store
     * @return int
     */
    public function getClearEmailLogDays($store = null)
    {
        return (int) $this->getConfigForCurrentSection(
            self::DEVELOPER_SECTION . '/clear_email_log',
            $store
        );
    }
}
