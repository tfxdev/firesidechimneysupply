/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

require([
    'jquery',
    'Magento_Ui/js/modal/alert',
    'domReady!'
], function ($, alert) {
    "use strict";

    var gatewaysSelect = $('#prsmtp_configuration_gateways'),
        autofill = $('#prsmtp_autofill');

    if (gatewaysSelect.val() === '0') {
        autofill.attr('disabled', true);
    } else {
        autofill.attr('disabled', false);
    }

    var autofillUrl = autofill.data('autofillUrl');

    autofill.click(function () {
        alert({
            title: $.mage.__('Set SMTP Configuration'),
            content: $.mage.__('SMTP Data will be overridden. Are you sure you want to do this?'),
            buttons: [{
                text: $.mage.__('Cancel'),
                class: 'action-primary prsmtp_autofill_close',
                click: function () {
                    this.closeModal();
                }
            }, {
                text: $.mage.__('Ok'),
                class: 'primary',
                click: function () {
                    autofill.attr('disabled', true);
                    this.closeModal();
                    $.ajax({
                        type: 'POST',
                        url: autofillUrl,
                        data: {provider: gatewaysSelect.val()}
                    }).done(function (data) {
                        if (data) {
                            var fields = {
                                host: '#prsmtp_configuration_host',
                                port: '#prsmtp_configuration_port',
                                encryption: '#prsmtp_configuration_encryption',
                                username: '#prsmtp_configuration_username',
                                password: '#prsmtp_configuration_password'
                            };

                            var authenticationField = false;
                            for (var field in fields) {
                                $(fields[field]).val(data[field]);
                                authenticationField = field === 'password' || field === 'username';
                                if (data['authentication'] === 'login' && authenticationField) {
                                    $('#prsmtp_configuration_authentication').val('login');
                                    $('#row_' + fields[field].slice(1)).show();
                                    $(fields[field]).show();
                                    $(fields[field]).removeAttr('disabled');
                                } else if (authenticationField) {
                                    $('#prsmtp_configuration_authentication').val(null);
                                    $('#row_' + fields[field].slice(1)).hide();
                                    $(fields[field]).hide();
                                    $(fields[field]).attr('disabled','disabled');
                                }
                            }
                        }
                        autofill.attr('disabled', false);
                    });
                }
            }]
        });
    });

    gatewaysSelect.on('change', function () {
        if (gatewaysSelect.val() === '0') {
            autofill.attr('disabled', true);
        } else {
            autofill.attr('disabled', false);
        }
    })
});
