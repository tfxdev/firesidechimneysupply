/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

require([
    'jquery',
    'Magento_Ui/js/modal/alert',
    'domReady!'
], function ($, alert) {
    "use strict";

    var sendEmailGeneralTest = $("#prsmtp_test_email_send");
    var sendEmailGatewayTest = $("#prsmtp_test_gateway_send");

    // Use in Store -> Configuration
    sendEmailGeneralTest.click(function () {
        var url = sendEmailGeneralTest.data('sendEmailTest');
        var formData = {
            'host': $('#prsmtp_configuration_host').val(),
            'port': $('#prsmtp_configuration_port').val(),
            'encryption': $('#prsmtp_configuration_encryption').val(),
            'authentication': $('#prsmtp_configuration_authentication').val(),
            'username': $('#prsmtp_configuration_username').val(),
            'password': $('#prsmtp_configuration_password').val(),
            'template': $('#prsmtp_test_email_template').val(),
            'from': $('#prsmtp_test_email_from').val(),
            'to': $('#prsmtp_test_email_to').val()
        };

        emailGatewayTest(formData, url);
    });

    // Use in Manage Gateways
    sendEmailGatewayTest.click(function () {
        var url = sendEmailGatewayTest.data('testEmailSend');
        var formData = {
            'host': $('[name="host"]').val(),
            'port': $('[name="port"]').val(),
            'encryption': $('[name="encryption"]').val(),
            'authentication': $('[name="authentication"]').val(),
            'username': $('[name="login"]').val(),
            'password': $('#password').val(),
            'template': $('[name="template"]').val(),
            'from': $('[name="from"]').val(),
            'to': $('[name="to"]').val()
        };

        emailGatewayTest(formData, url);
    });

    function emailGatewayTest(formData, url)
    {
        $('body').trigger('processStart');
        $.post(url, formData, function (data) {
            alert({
                title: $.mage.__('Send test email'),
                content: data.message ?? $.mage.__('Something went wrong.')
            });
        }).always(function () {
            $('body').trigger('processStop');
        }).fail(function (jqXHR) {
            let response = jqXHR.responseText,
                message;

            try {
                message = JSON.parse(response).message;
            } catch (e) {}

            try {
                message = message ?? JSON.parse(response.split("<br")[0]).message;
            } catch (e) {}

            $('#messages .messages').empty();
            alert({
                title: $.mage.__('Send test email'),
                content: message ?? $.mage.__('Something went wrong.')
            });
        });
    }
});
