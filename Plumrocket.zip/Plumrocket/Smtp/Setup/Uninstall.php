<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Smtp\Setup;

use Plumrocket\Base\Setup\AbstractUninstall;
use Plumrocket\Smtp\Model\ResourceModel\Gateway;
use Plumrocket\Smtp\Model\ResourceModel\Log;

class Uninstall extends AbstractUninstall
{
    /**
     * @var string
     */
    protected $_configSectionId = 'prsmtp';

    /**
     * Paths to files
     *
     * @var array
     */
    protected $_pathes = ['/app/code/Plumrocket/Smtp'];

    /**
     * @var array
     */
    protected $_tables = [
        Log::MAIN_TABLE_NAME,
        Gateway::MAIN_TABLE_NAME,
    ];
}
