<?php
/**
 * Plumrocket Inc.
 * NOTICE OF LICENSE
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Smtp\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Plumrocket\Smtp\Api\Data\GatewayInterface as GatewaysData;
use Plumrocket\Smtp\Api\Data\GatewayInterfaceFactory;
use Plumrocket\Smtp\Api\GatewayRegistryInterface;
use Plumrocket\Smtp\Model\ResourceModel\Gateway;

/**
 * @since 1.1.0
 */
class RecurringData implements InstallDataInterface
{
    /**
     * @var Gateway
     */
    private $gatewaysResource;

    /**
     * @var GatewayRegistryInterface
     */
    private $gatewaysRegistry;

    /**
     * @var GatewayInterfaceFactory
     */
    private $gatewaysFactory;

    /**
     * @param \Plumrocket\Smtp\Model\ResourceModel\Gateway      $gatewaysResource
     * @param \Plumrocket\Smtp\Api\GatewayRegistryInterface     $gatewaysRegistry
     * @param \Plumrocket\Smtp\Api\Data\GatewayInterfaceFactory $gatewayFactory
     */
    public function __construct(
        Gateway $gatewaysResource,
        GatewayRegistryInterface $gatewaysRegistry,
        GatewayInterfaceFactory $gatewayFactory
    ) {
        $this->gatewaysResource = $gatewaysResource;
        $this->gatewaysRegistry = $gatewaysRegistry;
        $this->gatewaysFactory = $gatewayFactory;
    }

    /**
     * RecurringData installer
     *
     * @param \Magento\Framework\Setup\ModuleDataSetupInterface $setup
     * @param \Magento\Framework\Setup\ModuleContextInterface   $context
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $installedGateways = $this->gatewaysResource->getAllGateways();
        $gateways = $this->gatewaysRegistry->getGateways();

        if ($gateways) {
            foreach ($gateways as $gatewayName => $gatewayData) {
                if (! in_array($gatewayName, $installedGateways, true)) {

                    /** @var GatewaysData $gateway */
                    $gateway = $this->gatewaysFactory->create();

                    $gateway->setName((string)$gatewayData[GatewaysData::NAME]);
                    $gateway->setActive((bool)$gatewayData[GatewaysData::ACTIVE]);
                    $gateway->setHost((string)$gatewayData[GatewaysData::HOST]);
                    $gateway->setPort((int)$gatewayData[GatewaysData::PORT]);

                    if (isset($gatewayData[GatewaysData::ENCRYPTION])) {
                        $gateway->setEncryption((string)$gatewayData[GatewaysData::ENCRYPTION]);
                    }

                    $this->gatewaysResource->save($gateway);
                }
            }
        }
    }
}
