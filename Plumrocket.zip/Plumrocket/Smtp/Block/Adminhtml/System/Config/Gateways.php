<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Smtp\Block\Adminhtml\System\Config;

use Magento\Framework\Data\Collection;
use Magento\Framework\View\Element\Context;
use Magento\Framework\View\Element\Html\Select as HtmlSelect;
use Plumrocket\Smtp\Model\ResourceModel\Gateway\CollectionFactory as GatewaysCollectionFactory;

/**
 * @since 1.1.0
 */
class Gateways extends HtmlSelect
{
    /**
     * @var GatewaysCollectionFactory
     */
    private $gatewayCollectionFactory;

    /**
     * Gateways constructor.
     *
     * @param \Plumrocket\Smtp\Model\ResourceModel\Gateway\CollectionFactory $gatewayCollectionFactory
     * @param \Magento\Framework\View\Element\Context                        $context
     * @param array                                                          $data
     */
    public function __construct(
        GatewaysCollectionFactory $gatewayCollectionFactory,
        Context $context,
        array $data = []
    ) {
        $this->gatewayCollectionFactory = $gatewayCollectionFactory;
        parent::__construct($context, $data);
    }

    /**
     * @return string
     */
    public function _toHtml()
    {
        if (! $this->getOptions()) {
            $this->addOption(0, (string) __('-- Select Email Gateway --'));

            /** @var \Plumrocket\Smtp\Model\ResourceModel\Gateway\Collection $collection  */
            $collection = $this->gatewayCollectionFactory->create();
            $collection->addFieldToFilter('active', ['eq' => 1]);
            $collection->addOrder('name', Collection::SORT_ORDER_ASC);

            foreach ($collection->getItems() as $gateway) {
                $this->addOption($gateway->getId(), $gateway->getName());
            }
        }

        return parent::_toHtml();
    }
}
