<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Smtp\Block\Adminhtml\System\Config\Form;

use Magento\Config\Block\System\Config\Form\Field as FormField;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Store\Model\ScopeInterface;
use Plumrocket\Smtp\Block\Adminhtml\System\Config\Gateways;

/**
 * @since 1.1.0
 */
class Autofill extends FormField
{

    /**
     * Set default template.
     *
     * @return $this
     */
    protected function _prepareLayout()
    {
        parent::_prepareLayout();
        if (! $this->getTemplate()) {
            $this->setTemplate('Plumrocket_Smtp::system/config/autofill.phtml');
        }
        return $this;
    }

    /**
     * Retrieve select element.
     *
     * @param string $id
     * @param string $name
     * @return string
     */
    public function selectRender($id, $name)
    {
        $selectValue = $this->_scopeConfig->getValue(
            'prsmtp/configuration/gateways',
            ScopeInterface::SCOPE_STORE
        );

        return $this->getLayout()->createBlock(
            Gateways::class,
            '',
            ['data' => ['is_render_to_js_template' => false]]
        )->setId($id)->setName($name)->setValue($selectValue)->toHtml();
    }

    /**
     * @param AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element)
    {
        return '<div id="prsmtp_gateways_autofill">'
            . $this->selectRender($element->getHtmlId(), $element->getName())
            . $this->_toHtml()
            . '</div>'
            . $this->getNote();
    }

    /**
     * Retrieve controller url
     *
     * @return string
     */
    public function getControllerUrl()
    {
        return $this->getUrl('prsmtp/gateways/parameters');
    }

    /**
     * @return string
     */
    private function getNote()
    {
        return '<p class="note"><span>' . __('Create or edit your Email Gateway on this page')
            . ' <a target="_blank" href="' . $this->getUrl('prsmtp/gateways/index')
            . '">'. __('Manage Email Gateways') . '</a></span></p>';
    }
}
