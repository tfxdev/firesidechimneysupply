<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Smtp\Plugin\Framework\Mail;

use Closure;
use Exception;
use Magento\Framework\Exception\MailException;
use Magento\Framework\Mail\TransportInterface;
use Magento\Framework\Phrase;
use Plumrocket\Smtp\Model\Config\Source\Status;
use Zend_Exception;

class TransportPlugin
{
    /**
     * @var string
     */
    private const NULL_STRING = '0';

    /**
     * @var \Plumrocket\Smtp\Model\Mail
     */
    private $mail;

    /**
     * @var \Magento\Framework\Registry
     */
    private $registry;

    /**
     * @var \Plumrocket\Smtp\Model\LogFactory
     */
    private $emailLogFactory;

    /**
     * @var \Plumrocket\Smtp\Helper\Config
     */
    private $config;

    /**
     * TransportPlugin constructor.
     *
     * @param \Plumrocket\Smtp\Model\Mail       $mail
     * @param \Magento\Framework\Registry       $registry
     * @param \Plumrocket\Smtp\Helper\Data      $dataHelper
     * @param \Plumrocket\Smtp\Model\LogFactory $emailLogFactory
     * @param \Plumrocket\Smtp\Helper\Config    $config
     */
    public function __construct(
        \Plumrocket\Smtp\Model\Mail $mail,
        \Magento\Framework\Registry $registry,
        \Plumrocket\Smtp\Helper\Data $dataHelper,
        \Plumrocket\Smtp\Model\LogFactory $emailLogFactory,
        \Plumrocket\Smtp\Helper\Config $config
    ) {
        $this->mail = $mail;
        $this->registry = $registry;
        $this->emailLogFactory = $emailLogFactory;
        $this->config = $config;
    }

    /**
     * Perform custom sending if module enabled.
     *
     * @param TransportInterface $subject
     * @param Closure            $proceed
     * @return void
     * @throws MailException
     * @throws Zend_Exception
     */
    public function aroundSendMessage(
        TransportInterface $subject,
        Closure $proceed
    ) {
        $storeId = $this->registry->registry('plumrocket_smtp_store_id');

        if (! $this->config->isModuleEnabled($storeId)) {
            $proceed();
            return;
        }

        $message = $subject->getMessage();

        if (! $message) {
            $proceed();
            return;
        }

        $debugInfo = (string) __('Email was sent successfully.');

        // For Magento older than 2.3.6
        if (! class_exists(\Laminas\Mail\Message::class)) {
            $message = \Zend\Mail\Message::fromString($message->getRawMessage())->setEncoding('utf-8');
        } else {
            $message = \Laminas\Mail\Message::fromString($message->getRawMessage())->setEncoding('utf-8');
        }

        try {
            if ($this->config->getEmailSendingEnabled($storeId)) {
                $transportObject = $this->mail->getTransport($storeId);
                $transportObject->send($message);
            }
            $this->setBodyMultipart($subject, $message);
            $status = Status::STATUS_SUCCESS;
        } catch (Exception $exception) {
            $status = Status::STATUS_ERROR;
            $debugInfo = (string) $exception->getMessage();
        }

        $this->saveEmailLog($message, $storeId, $status, $debugInfo);

        if ($status === Status::STATUS_ERROR) {
            throw new MailException(new Phrase($debugInfo));
        }
    }

    /**
     * Save email log.
     *
     * @param \Magento\Framework\Mail\MessageInterface|object $message
     * @param string|int                                      $store
     * @param int                                             $status
     * @param string                                          $debugInfo
     * @return void
     */
    private function saveEmailLog($message, $store, int $status, string $debugInfo): void
    {
        if ($this->config->getLogEnabled($store)) {
            /** @var \Plumrocket\Smtp\Model\Log $logModel */
            $logModel = $this->emailLogFactory->create();
            $logModel->addLog($message, $status, $debugInfo);
        }
    }

    /**
     * Set body multipart.
     *
     * @param \Magento\Framework\Mail\TransportInterface      $subject
     * @param \Magento\Framework\Mail\MessageInterface|object $message
     */
    private function setBodyMultipart(TransportInterface $subject, $message): void
    {
        $messageTmp = $subject->getMessage();
        if ($messageTmp && is_object($messageTmp)) {
            $emailBodyObject = $messageTmp->getBody();

            if (is_object($emailBodyObject) && $emailBodyObject->isMultiPart()) {
                $message->setBody($emailBodyObject->getPartContent(self::NULL_STRING));
            }
        }
    }
}
