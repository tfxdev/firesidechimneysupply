<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Smtp\Plugin\Framework\Mail\Template;

use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Registry;
use Plumrocket\Smtp\Helper\Config;

class TransportBuilderPlugin
{
    /**
     * @var \Magento\Framework\Registry
     */
    private $registryObject;

    /**
     * @var \Plumrocket\Smtp\Helper\Config
     */
    private $config;

    /**
     * @param \Magento\Framework\Registry    $registry
     * @param \Plumrocket\Smtp\Helper\Config $config
     */
    public function __construct(
        Registry $registry,
        Config $config
    ) {
        $this->registryObject = $registry;
        $this->config = $config;
    }

    /**
     * Remember store id.
     *
     * @param \Magento\Framework\Mail\Template\TransportBuilder $subject
     * @param array                                             $templateOptions
     * @return array
     */
    public function beforeSetTemplateOptions(
        TransportBuilder $subject,
        $templateOptions
    ) {
        if ($this->config->isModuleEnabled($templateOptions['store'])) {
            $this->registryObject->unregister('plumrocket_smtp_store_id');

            if (array_key_exists('store', $templateOptions)) {
                $this->registryObject->register('plumrocket_smtp_store_id', $templateOptions['store']);
            }
        }

        return [$templateOptions];
    }
}
