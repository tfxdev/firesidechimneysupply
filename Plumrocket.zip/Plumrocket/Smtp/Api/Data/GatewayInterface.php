<?php
/**
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (https://plumrocket.com)
 * @license     https://plumrocket.com/license   End-user License Agreement
 */

namespace Plumrocket\Smtp\Api\Data;

/**
 * Gateway Data Interface
 *
 * @since 1.1.0
 */
interface GatewayInterface
{
    public const NAME = 'name';
    public const ACTIVE = 'active';
    public const HOST = 'host';
    public const PORT = 'port';
    public const ENCRYPTION = 'encryption';
    public const AUTHENTICATION = 'authentication';
    public const LOGIN = 'login';
    public const PASSWORD = 'password';

    /**
     * Get getaway identifier
     *
     * @return string|int
     */
    public function getId();

    /**
     * Get name
     *
     * @return string
     */
    public function getName(): string;

    /**
     * Set name
     *
     * @param string $gatewayName
     * @return GatewayInterface
     */
    public function setName(string $gatewayName): GatewayInterface;

    /**
     * Check is active
     *
     * @return bool
     */
    public function isActive(): bool;

    /**
     * Set is active
     *
     * @param bool $flag
     * @return GatewayInterface
     */
    public function setActive(bool $flag): GatewayInterface;

    /**
     * Get host
     *
     * @return string
     */
    public function getHost(): string;

    /**
     * Set host
     *
     * @param string $host
     * @return GatewayInterface
     */
    public function setHost(string $host): GatewayInterface;

    /**
     * Set port
     *
     * @param int $port
     * @return GatewayInterface
     */
    public function setPort(int $port) : GatewayInterface;

    /**
     * Get post
     *
     * @return int
     */
    public function getPort(): int;

    /**
     * Set encryption
     *
     * @param string $encryption
     * @return GatewayInterface
     */
    public function setEncryption(string $encryption): GatewayInterface;

    /**
     * Get encryption
     *
     * @return string
     */
    public function getEncryption(): string;

    /**
     * Set auth method
     *
     * @param string $authentication
     * @return GatewayInterface
     */
    public function setAuthentication(string $authentication): GatewayInterface;

    /**
     * Get auth method
     *
     * @return string
     */
    public function getAuthentication(): string;

    /**
     * Set smtp user login
     *
     * @param string $login
     * @return GatewayInterface
     */
    public function setLogin(string $login): GatewayInterface;

    /**
     * Get smtp user login
     *
     * @return string
     */
    public function getLogin(): string;

    /**
     * Set smtp user password
     *
     * @param string $password
     * @return GatewayInterface
     */
    public function setPassword(string $password): GatewayInterface;

    /**
     * Get smtp user password
     *
     * @return string
     */
    public function getPassword(): string;
}
