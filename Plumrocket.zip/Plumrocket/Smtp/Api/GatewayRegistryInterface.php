<?php
/**
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (https://plumrocket.com)
 * @license     https://plumrocket.com/license   End-user License Agreement
 */

namespace Plumrocket\Smtp\Api;

/**
 * Gateway Registry.
 *
 * You can add Gateway by pass into constructor
 * or using After plugin on getGateways method
 * They'll be installed during recurring step of setup:upgrade
 *
 * @since 1.1.0
 */
interface GatewayRegistryInterface
{
    /**
     * Get list of getaways.
     *
     * @return array[]
     */
    public function getGateways() : array;
}
