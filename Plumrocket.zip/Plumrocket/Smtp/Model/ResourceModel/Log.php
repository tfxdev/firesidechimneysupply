<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Smtp\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Log extends AbstractDb
{
    public const MAIN_TABLE_NAME = 'plumrocket_smtp_email_log';
    public const ID_FIELD_NAME = 'entity_id';

    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct() //@codingStandardsIgnoreLine default magento functionality
    {
        $this->_init(self::MAIN_TABLE_NAME, self::ID_FIELD_NAME);
    }

    /**
     * Clear all logs.
     *
     * @return void
     */
    public function clearAllLogs(): void
    {
        $this->getConnection()->truncateTable($this->getTable(self::MAIN_TABLE_NAME));
    }

    /**
     * Clear logs by date.
     *
     * @param int $date
     * @return void
     */
    public function clearLogsUntilDate(int $date)
    {
        $date = date('Y-m-d H:i:s', $date);
        $this->getConnection()->delete($this->getTable(self::MAIN_TABLE_NAME), ['sent_at <= ?' => $date]);
    }
}
