<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Smtp\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * @since 1.1.0
 */
class Gateway extends AbstractDb
{
    /**
     * Name of Main Table
     */
    public const MAIN_TABLE_NAME = 'plumrocket_smtp_gateways';

    /**
     * Name of Primary Column
     */
    public const ID_FIELD = 'entity_id';

    /**
     * @inheritdoc
     */
    protected function _construct()
    {
        $this->_init(self::MAIN_TABLE_NAME, self::ID_FIELD);
    }

    /**
     * Get names of all getaways.
     *
     * @return string[]
     */
    public function getAllGateways() : array
    {
        $connection = $this->getConnection();
        $select = $connection->select()->from(
            $this->getTable(self::MAIN_TABLE_NAME),
            'name'
        );

        return $connection->fetchCol($select);
    }
}
