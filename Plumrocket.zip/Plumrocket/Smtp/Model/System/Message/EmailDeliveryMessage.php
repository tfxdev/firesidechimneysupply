<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Smtp\Model\System\Message;

use Magento\Framework\Notification\MessageInterface;

/**
 * @since 1.1.0
 */
class EmailDeliveryMessage implements MessageInterface
{

    /**
     * @var \Plumrocket\Smtp\Helper\Config
     */
    private $config;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    private $urlBuilder;

    /**
     * @param \Plumrocket\Smtp\Helper\Config             $config
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\UrlInterface            $urlBuilder
     */
    public function __construct(
        \Plumrocket\Smtp\Helper\Config $config,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\UrlInterface $urlBuilder
    ) {
        $this->config = $config;
        $this->storeManager = $storeManager;
        $this->urlBuilder = $urlBuilder;
    }

    /**
     * Retrieve unique message identity.
     *
     * @return string
     */
    public function getIdentity()
    {
        return 'prsmtp_message';
    }

    /**
     * Return true to show your message, false to hide it.
     *
     * @return bool
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function isDisplayed()
    {
        return ! $this->config->getEmailSendingEnabled($this->storeManager->getStore()->getId());
    }

    /**
     * Get message text.
     *
     * @return string
     */
    public function getText(): string
    {
        $url = $this->urlBuilder->getUrl(
            'adminhtml/system_config/edit',
            ['section' => 'prsmtp', '_fragment' => 'prsmtp_developer_email_sending']
        );

        return (string) __(
            'Attention: Email delivery is disabled in Plumrocket SMTP. ' .
            'Click <a href="%1">here</a> to enable \'Email Delivery\'.',
            $url
        );
    }

    /**
     * Possible values: SEVERITY_CRITICAL, SEVERITY_MAJOR, SEVERITY_MINOR, SEVERITY_NOTICE
     *
     * @return int
     */
    public function getSeverity(): int
    {
        return self::SEVERITY_CRITICAL;
    }
}
