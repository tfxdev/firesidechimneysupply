<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Smtp\Model\Config\Source;

use Magento\Config\Model\Config\Source\Email\Template as EmailTemplates;

/**
 * @since 1.1.0
 */
class Emails extends EmailTemplates
{
    /**
     * Get options.
     *
     * @return array
     */
    public function toOptionArray()
    {
        $collection = $this->_templatesFactory->create();
        $collection->load();
        $options = $collection->toOptionArray();
        $templateId = str_replace('/', '_', 'prsmtp/test_email/template');
        array_unshift($options, ['value' => $templateId, 'label' => __('Default SMTP Test Template (Default)')]);
        array_walk(
            $options,
            function (&$item) {
                $item['__disableTmpl'] = true;
            }
        );

        return $options;
    }
}
