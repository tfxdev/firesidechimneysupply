<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Smtp\Model;

use Plumrocket\Smtp\Helper\Data;
use Zend_Exception;

class Mail
{
    /**
     * @var Data
     */
    protected $dataHelper;

    /**
     * @var
     */
    protected $message;

    /**
     * @var
     */
    protected $transport;

    /**
     * Mail constructor.
     *
     * @param Data $helper
     *
     */
    public function __construct(Data $helper)
    {
        $this->dataHelper = $helper;
    }

    /**
     * @param $storeId
     * @return \Laminas\Mail\Transport\Smtp|\Zend\Mail\Transport\Smtp
     * @throws \Zend_Exception
     */
    public function getTransport($storeId)
    {
        if (null !== $this->transport) {
            return $this->transport;
        }

        if (! $this->dataHelper->hostExist($storeId)) {
            throw new Zend_Exception(__('The host is not specified. Please check the extension configuration.'));
        }

        $optionsNewVersions = $this->dataHelper->getOptionsForNewVersion($storeId);

        // For Magento older than 2.3.6
        if (! class_exists(\Laminas\Mail\Transport\Smtp::class)) {
            $options = new \Zend\Mail\Transport\SmtpOptions($optionsNewVersions);
            $this->transport = new \Zend\Mail\Transport\Smtp($options);
        } else {
            $options = new \Laminas\Mail\Transport\SmtpOptions($optionsNewVersions);
            $this->transport = new \Laminas\Mail\Transport\Smtp();
            $this->transport->setOptions($options);
        }

        return $this->transport;
    }
}
