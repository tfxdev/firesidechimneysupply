<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Smtp\Model;

class Log extends \Magento\Framework\Model\AbstractModel
{

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    private $date;

    /**
     * @var \Magento\Framework\Escaper
     */
    private $escaper;

    /**
     * @param \Magento\Framework\Escaper                                   $escaper
     * @param \Magento\Framework\Stdlib\DateTime\DateTime                  $date
     * @param \Magento\Framework\Model\Context                             $context
     * @param \Magento\Framework\Registry                                  $registry
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null           $resourceCollection
     * @param array                                                        $data
     */
    public function __construct(
        \Magento\Framework\Escaper $escaper,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
        $this->escaper = $escaper;
        $this->date = $date;
    }

    /**
     * Email Init
     */
    protected function _construct()
    {
        $this->_init(ResourceModel\Log::class);
    }

    /**
     * Add message to email log.
     *
     * @param object $messageObject
     * @param int    $status
     * @param string $debugInfo
     * @return $this
     */
    public function addLog($messageObject, int $status, string $debugInfo)
    {
        $emailHtmlContent = $this->escaper->escapeHtml($messageObject->getBodyText());
        $this->setBody($emailHtmlContent);

        if ($messageObject->getSubject()) {
            $this->setSubject($messageObject->getSubject());
        }

        $fromEmail = $messageObject->getFrom();

        if (count($fromEmail)) {
            $fromEmail->rewind();
            $this->setEmailFrom($fromEmail->current()->getEmail());
        }

        $toEmailArray = [];
        foreach ($messageObject->getTo() as $toEmailAddress) {
            $toEmailArray[] = $toEmailAddress->getEmail();
        }

        $this->setEmailTo(implode(',', $toEmailArray));

        $this->setStatus($status);
        $this->setSentAt($this->date->gmtDate());
        $this->setDebugLog($debugInfo);
        $this->save();

        return $this;
    }
}
