<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Smtp\Model;

use Magento\Framework\Model\AbstractModel;
use Plumrocket\Smtp\Api\Data\GatewayInterface;
use Plumrocket\Smtp\Model\ResourceModel\Gateway as GatewaysResourceModel;

/**
 * @since 1.1.0
 */
class Gateway extends AbstractModel implements GatewayInterface
{
    /**
     * @inheritdoc
     */
    public function _construct()
    {
        $this->_init(GatewaysResourceModel::class);
    }

    /**
     * @inheritdoc
     */
    public function getName(): string
    {
        return (string) $this->getData(GatewayInterface::NAME);
    }

    /**
     * @inheritdoc
     */
    public function setName(string $gatewayName): GatewayInterface
    {
        return $this->setData(GatewayInterface::NAME, $gatewayName);
    }

    /**
     * @inheritdoc
     */
    public function isActive(): bool
    {
        return (bool) $this->getData(GatewayInterface::ACTIVE);
    }

    /**
     * @inheritdoc
     */
    public function setActive(bool $active): GatewayInterface
    {
        return $this->setData(GatewayInterface::ACTIVE, $active);
    }

    /**
     * @inheritdoc
     */
    public function getHost(): string
    {
        return (string) $this->getData(GatewayInterface::HOST);
    }

    /**
     * @inheritdoc
     */
    public function setHost(string $host): GatewayInterface
    {
        return $this->setData(GatewayInterface::HOST, $host);
    }

    /**
     * @inheritdoc
     */
    public function setPort(int $port): GatewayInterface
    {
        return $this->setData(GatewayInterface::PORT, $port);
    }

    /**
     * @inheritdoc
     */
    public function getPort(): int
    {
        return (int) $this->getData(GatewayInterface::PORT);
    }

    /**
     * @inheritdoc
     */
    public function setEncryption(string $encryption): GatewayInterface
    {
        return $this->setData(GatewayInterface::ENCRYPTION, $encryption);
    }

    /**
     * @inheritdoc
     */
    public function getEncryption(): string
    {
        return (string) $this->getData(GatewayInterface::ENCRYPTION);
    }

    /**
     * @inheritdoc
     */
    public function setAuthentication(string $authentication): GatewayInterface
    {
        return $this->setData(GatewayInterface::AUTHENTICATION, $authentication);
    }

    /**
     * @inheritdoc
     */
    public function getAuthentication(): string
    {
        return (string) $this->getData(GatewayInterface::AUTHENTICATION);
    }

    /**
     * @inheritdoc
     */
    public function setLogin(string $login): GatewayInterface
    {
        return $this->setData(GatewayInterface::LOGIN, $login);
    }

    /**
     * @inheritdoc
     */
    public function getLogin(): string
    {
        return (string) $this->getData(GatewayInterface::LOGIN);
    }

    /**
     * @inheritdoc
     */
    public function setPassword(string $password): GatewayInterface
    {
        return $this->setData(GatewayInterface::PASSWORD, $password);
    }

    /**
     * @inheritdoc
     */
    public function getPassword(): string
    {
        return (string) $this->getData(GatewayInterface::PASSWORD);
    }
}
