<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Smtp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Smtp\Ui\DataProvider\Gateways\Form;

use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Plumrocket\Smtp\Model\ResourceModel\Gateway\CollectionFactory as GatewaysCollectionFactory;

/**
 * @since 1.1.0
 */
class DataProvider extends AbstractDataProvider
{
    /**
     * @var EncryptorInterface
     */
    protected $encryptor;

    /**
     * @var EncryptorInterface
     */
    protected $loadedData;

    /**
     * DataProvider constructor.
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param GatewaysCollectionFactory $gatewaysCollectionFactory
     * @param EncryptorInterface $encryptor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        string $name,
        string $primaryFieldName,
        string $requestFieldName,
        GatewaysCollectionFactory $gatewaysCollectionFactory,
        EncryptorInterface $encryptor,
        array $meta = [],
        array $data = []
    ) {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);

        $this->collection = $gatewaysCollectionFactory->create();
        $this->encryptor = $encryptor;
    }

    /**
     * @inheritdoc
     */
    public function getData()
    {
        if (null === $this->loadedData) {
            $this->loadedData = [];
            $gateways = $this->collection->getItems();
            foreach ($gateways as $gateway) {
                $data = $gateway->getData();
                $data['password'] = $this->encryptor->decrypt($data['password']);
                $this->loadedData[$gateway->getId()] = $data;
            }
        }

        return $this->loadedData;
    }
}
